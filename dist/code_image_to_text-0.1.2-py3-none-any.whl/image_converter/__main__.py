from .code_recognizer import *

app()